const http = require("http");
const fs = require("fs");
const port = 8080;
const server = http.createServer((request,response)=>{

    if (request.url == "/" && request.method == "GET"){

        fs.readFile("./db.json","utf-8",(error,data)=>{
            if(error){
                response.end("Something Fishy....🐟");
            }
            else{
                response.end(data);
            }
        })

    }
    else
    {
        response.end("Can't Figure Out What's Going On...😊😊😊")
    }


})

server.listen(port,()=>{
    console.log(`The Server is Running At ${port}`);
})