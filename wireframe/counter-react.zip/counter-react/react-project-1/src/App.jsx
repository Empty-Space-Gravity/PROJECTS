import { useState } from "react";
import "./App.css"
export default function App() {

    let [value,setValue] = useState(0);

    const Increment = ()=>{
        setValue(value+1);
    }

    const Decrement = ()=>{
        setValue(value-1);
    }
    return (
        <div>
            
            <div className="playground ml-120 mt-20 w-200 rounded-3xl shadow-2xl shadow-gray-700 ">

                <h1 className="text-center text-white text-5xl pt-4">Counter</h1>
                <p className="text-black text-3xl text-center mt-20 bg-white rounded-2xl w-50 h-10 ml-43">Count : {value}</p>
                <button className="rounded-4xl border-2 p-2 text-white relative top-50 left-32 hover:bg-white hover:text-black" onClick={Increment}>Increment</button>
                <button className="rounded-4xl border-2 p-2  text-white relative top-50 left-55 hover:bg-white hover:text-black" onClick={Decrement}>Decrement</button>
 
            </div>

        </div>
    );
}


