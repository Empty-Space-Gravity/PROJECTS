import "./style.css";

function Navbar()
{
    return(
    <>  
    <div className="img">    
            
    </div>
    
    <div className="header-content">
        <h1 className="limelight-regular">User-first designs that grow brands and delight users</h1>
        <p className="lato-regular text">Beautiful interfaces. Measurable results.</p>
        <a href="#">Log-In</a>
        <a href="#">Sign-Up</a>
    </div>
 
    <div className="Navbar-container">
        
        <div className="Navbar">
                <div className="logo-name-container">
                    
                    <img src="src/assets/flame.png" id="fire" alt="fire" />
                    <a href="#" id="affect">Fire</a>
                </div>
                <div className="content">
                    <a href="#">About Us</a>
                    <a href="#">Contact</a>
                    <a href="#">Designs</a>
                </div>
        </div>
    </div>

   
    </>);


}

export default Navbar;