// let arr = [1,2,3,4,5,"yuvraj"];
// let arr2 = ["Nice", "Hi","😊","🤬"];

// let combine = [...arr , ...arr2];

// combine.forEach(element => {
//     console.log(element)
// });

// it is the map method 
// let new_array = arr.map((Element) => {
//     return (Element * 2) * 3;
// })

// console.log(new_array)

// let name = arr.filter((element)=>{
//     return element == "yuvraj";
// });

// let name_id = arr.map((element)=> 
// {
//      return element +  1;
// });

// console.log(name);
// console.log(name_id);


// `let User_Data = 
//     {
//         name:"yuvraj",
//         mood:"🥂"
//     }


// let {name} = User_Data;
// let {mood} = User_Data
// console.log(name);
// console.log(mood);

    

// User_Data.forEach((element)=> 
// {
//     console.log(`Name : ${element.name} Mood:${element.mood}`);
// })



