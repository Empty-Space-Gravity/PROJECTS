export default function Main()
{
    return(
        <>
            <main>
                <div className="grid">
                    <div className="card-1">
                        <img src="src/assets/download (1).jpg" alt="img1" />
                    </div>
                    <div className="card-2">
                        <img src="src/assets/download (2).jpg" alt="img2" />
                    </div>
                    <div className="card-3">
                        <img src="src/assets/download (3).jpg" alt="img3" />
                    </div>
                    <div className="card-4">
                        <img src="src/assets/download.jpg" alt="img4" />
                    </div>
                </div>
            </main>
        </>
    )
}

