import { Container } from 'react-bootstrap';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
function TextControlsExample() {
  return (
    <Container style={{marginTop:'350px', paddingTop:'30px', marginBottom:'50px'}}>
        <h1 className='text-center mb-5' style={{fontSize:"70px"}}>Contact Me</h1>
    <Form style={{width:"50%", margin:"auto" , fontSize:"25px", outline:"none", border:"none"}}>
      <Form.Group className="mb-4" controlId="exampleForm.ControlInput1">
        <Form.Label>Name</Form.Label>
        <Form.Control type="email" placeholder="eg.Yuvraj" />
      </Form.Group> 
            
      <Form.Group className="mb-4" controlId="exampleForm.ControlInput1">
        <Form.Label>Last Name</Form.Label>
        <Form.Control type="email" placeholder="eg.Sharma" />
      </Form.Group> 
      <Form.Group className="mb-4" controlId="exampleForm.ControlInput1">
        <Form.Label>Email address</Form.Label>
        <Form.Control type="email" placeholder="name@example.com" />
      </Form.Group> 
      
      <Form.Group className="mb-4" controlId="exampleForm.ControlTextarea1">
        <Form.Label>Message</Form.Label>
        <Form.Control as="textarea" rows={10} />
      </Form.Group>
       <Button variant="warning" type="submit" style={{marginLeft:"230px" , padding:"10px 50px" , fontSize:"20px"}}>
        Submit
      </Button>
    </Form>
    </Container>
  );
}

export default TextControlsExample;