import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';

function BasicExample() {
  return (
    <Navbar expand="lg" className="bg-body-tertiary">
      <Container>
        <Navbar.Brand href="#home" style={{fontSize:"40px"}}>Portfolio</Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto" style={{marginLeft:"30px"}}>
            <Nav.Link href="#Home" style={{fontSize:"20px" , paddingRight:"10px" ,paddingTop:'15px'}}>Home</Nav.Link>
            <Nav.Link href="#Skills" style={{fontSize:"20px" ,paddingRight:"10px",paddingTop:'15px'}}>Skills</Nav.Link>
            <Nav.Link href="#Project" style={{fontSize:"20px",paddingRight:"10px",paddingTop:'15px'}}>Projects</Nav.Link>
            <Nav.Link href="#Contact" style={{fontSize:"20px",paddingRight:"10px",paddingTop:'15px'}}>Contact</Nav.Link>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default BasicExample;