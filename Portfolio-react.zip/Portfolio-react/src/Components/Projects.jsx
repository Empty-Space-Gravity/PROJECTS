import Carousel from 'react-bootstrap/Carousel';

function CarouselFadeExample() {
  return (
    <Carousel style={{width:"100%", height:"500px" , margin:"auto" , marginTop:"30px"}}>
      <Carousel.Item>
        <img src="public/project-1.png" style={{width:"100%", height:"100%"}}  alt="" />
        <Carousel.Caption>
          <h3>Counter Project</h3>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img src="public/project-2.png" style={{width:"100%", height:"100%"}} alt="" />
        <Carousel.Caption>
          <h3>React Website</h3>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img src="public/project-3.png" style={{width:"100%", height:"100%"}} alt="" />
        <Carousel.Caption>
          <h3>Graphic Card</h3>
          
        </Carousel.Caption>
      </Carousel.Item>
      
      <Carousel.Item>
        <img src="public/project-4.png" style={{width:"100%", height:"100%"}} alt="" />
        <Carousel.Caption>
          <h3>Car Card Design</h3>
          
        </Carousel.Caption>
      </Carousel.Item>
    </Carousel>
  );
}

export default CarouselFadeExample;