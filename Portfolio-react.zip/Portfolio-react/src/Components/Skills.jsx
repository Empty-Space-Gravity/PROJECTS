import ProgressBar from 'react-bootstrap/ProgressBar';
import Container from 'react-bootstrap/Container';


function AnimatedExample() {
  return (
    <>

    <Container style={{marginTop:50, marginBottom:90}}>
    <h1 style={{textAlign:"center", marginBottom:"10px"}}>Skills</h1>
    <h2 style={{marginLeft:"12px"}}>HTML</h2>        
    <Container style={{marginBottom:20}}>
        <ProgressBar animated now={95} variant="danger" />
    </Container>
    <h2 style={{marginLeft:"12px"}}>JavaScript</h2>
    <Container style={{marginBottom:20}}>
        <ProgressBar animated now={50} variant="warning" />
    </Container>
    <h2 style={{marginLeft:"12px"}}>C++/C</h2>
    <Container style={{marginBottom:20}}>
        <ProgressBar animated now={80} variant="primary" />
    </Container>
    <h2 style={{marginLeft:"12px"}}>CSS</h2>
    <Container style={{marginBottom:20}}>
        <ProgressBar animated now={90} variant="success" />
    </Container>
    <h2 style={{marginLeft:"12px"}}>React</h2>
    <Container>
        <ProgressBar animated now={64} variant="primary" />
    </Container>
    </Container>
    <></>
    </>
  );
}

export default AnimatedExample;