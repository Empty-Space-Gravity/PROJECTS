import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';

function Home() {
  return(
      <Container-fluid>
    
        <img src="public/tie.jpg" style={{width:"100%" ,filter:"blur(3px)"}} />
      
        <h1 style={{position:"absolute", top:"150px", left:"0px" , color:"white" , fontSize:"160px" , textAlign:"center"}}>FULL STACK DEVELOPER</h1>
        <p style={{position:"absolute", top:"550px", left:"150px" , color:"white" , fontSize:"20px" , textAlign:"center" , width:"80%"}}>Hi, I’m Yuvraj Sharma. I’m a curious web development learner who enjoys building interactive experiences, exploring new technologies, and improving UI design skills through continuous hands-on practice.</p>
      </Container-fluid>
  );
}

export default Home