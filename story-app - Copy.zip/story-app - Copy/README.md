# Story App

A distraction-free story writing application with local autosave and export capabilities.

## Features

### 1. Auto-Save Drafts
- Your work is automatically saved to your browser's Local Storage every 1.5 seconds after you stop typing.
- An indicator in the top right shows the current status: "Saving..." or "Saved".
- **Note**: If you clear your browser data, your drafts will be lost. Export important work regularly.

### 2. Focus Mode
- Toggle Focus Mode to hide all distractions and focus purely on writing.
- **Shortcut**: `Ctrl + Shift + F`
- **Exit**: Press `ESC` or toggle the button again.

### 3. Story Progress Bar
- Set a target word count to see a visual progress bar at the top of the editor.
- Colors indicate progress:
  - Red: < 50%
  - Amber: 50% - 89%
  - Green: 90%+

### 4. Export
- **Text (.txt)**: Download your story as a plain text file.
- **PDF**: Opens a print-friendly view. Use your browser's "Save as PDF" option in the print dialog.

## Local Storage Keys
This app uses the following keys in Local Storage:
- `storyapp:drafts`: All your saved stories.
- `storyapp:currentDraftId`: The ID of the currently open story.
- `storyapp:autosaveIntervalMs`: Configuration for autosave interval.
- `storyapp:dismissedFocusHint`: Remembers if you've seen the Focus Mode hint.
