/**
 * Export Module
 * Handles client-side export of stories to TXT and PDF.
 */

export const Export = {
    /**
     * Export draft as a .txt file download
     * @param {Object} draft - The draft object { title, content, ... }
     */
    toTXT(draft) {
        if (!draft) return;

        const title = draft.title || 'Untitled Story';
        const date = new Date(draft.updatedAt).toLocaleString();

        const fileContent = `Title: ${title}\nDate: ${date}\n\n${draft.content}`;

        const blob = new Blob([fileContent], { type: 'text/plain;charset=utf-8' });
        const url = URL.createObjectURL(blob);

        const a = document.createElement('a');
        a.href = url;
        a.download = `${title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.txt`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    },

    /**
     * Export draft as PDF using browser print dialog
     * @param {Object} draft - The draft object { title, content, ... }
     */
    toPDF(draft) {
        if (!draft) return;

        const title = draft.title || 'Untitled Story';
        const date = new Date(draft.updatedAt).toLocaleString();
        // Convert newlines to <br> for HTML display, preserving paragraphs
        const formattedContent = draft.content
            .split('\n')
            .map(para => para.trim() ? `<p>${para}</p>` : '<br>')
            .join('');

        const printWindow = window.open('', '_blank');

        if (!printWindow) {
            alert('Please allow popups to export as PDF');
            return;
        }

        const html = `
            <!DOCTYPE html>
            <html>
            <head>
                <title>${title}</title>
                <style>
                    body {
                        font-family: 'Georgia', serif;
                        line-height: 1.6;
                        color: #000;
                        max-width: 800px;
                        margin: 0 auto;
                        padding: 40px;
                    }
                    h1 {
                        text-align: center;
                        margin-bottom: 10px;
                    }
                    .meta {
                        text-align: center;
                        color: #666;
                        font-size: 0.9em;
                        margin-bottom: 40px;
                        border-bottom: 1px solid #eee;
                        padding-bottom: 20px;
                    }
                    p {
                        margin-bottom: 1em;
                        text-align: justify;
                    }
                    @media print {
                        body { padding: 0; }
                        @page { margin: 2cm; }
                    }
                </style>
            </head>
            <body>
                <h1>${title}</h1>
                <div class="meta">Last updated: ${date}</div>
                <div class="content">
                    ${formattedContent}
                </div>
                <script>
                    window.onload = function() {
                        window.print();
                        // Optional: close after print
                        // window.onafterprint = function() { window.close(); }
                    }
                </script>
            </body>
            </html>
        `;

        printWindow.document.write(html);
        printWindow.document.close();
    }
};
