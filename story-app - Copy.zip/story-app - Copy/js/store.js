const STORAGE_KEY = 'storyApp.stories';
const USERS_KEY = 'story_app_users';
const SESSION_KEY = 'story_app_session';

export const Store = {
    // Stories
    getStories() {
        const data = localStorage.getItem(STORAGE_KEY);
        return data ? JSON.parse(data) : [];
    },

    getStory(id) {
        const stories = this.getStories();
        return stories.find(s => s.id === id);
    },

    addStory(story) {
        const user = this.getCurrentUser();
        if (!user) throw new Error('Must be logged in');

        const stories = this.getStories();
        const newStory = {
            ...story,
            id: Date.now().toString(),
            createdAt: new Date().toISOString(),
            authorId: user.username,
            authorName: user.username // Simplified for now
        };
        stories.unshift(newStory);
        this.saveStories(stories);
        return newStory;
    },

    updateStory(id, updatedData) {
        const stories = this.getStories();
        const index = stories.findIndex(s => s.id === id);
        if (index !== -1) {
            stories[index] = { ...stories[index], ...updatedData };
            this.saveStories(stories);
            return stories[index];
        }
        return null;
    },

    deleteStory(id) {
        const stories = this.getStories();
        const filteredStories = stories.filter(s => s.id !== id);
        this.saveStories(filteredStories);
    },

    saveStories(stories) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(stories));
    },

    // Auth
    getUsers() {
        const data = localStorage.getItem(USERS_KEY);
        return data ? JSON.parse(data) : [];
    },

    saveUsers(users) {
        localStorage.setItem(USERS_KEY, JSON.stringify(users));
    },

    getCurrentUser() {
        const data = localStorage.getItem(SESSION_KEY);
        return data ? JSON.parse(data) : null;
    },

    login(username, password) {
        const users = this.getUsers();
        const user = users.find(u => u.username === username && u.password === password);
        if (user) {
            localStorage.setItem(SESSION_KEY, JSON.stringify({ username: user.username }));
            return true;
        }
        return false;
    },

    register(username, password) {
        const users = this.getUsers();
        if (users.find(u => u.username === username)) {
            return false; // User exists
        }
        users.push({ username, password });
        this.saveUsers(users);
        this.login(username, password); // Auto login
        return true;
    },

    logout() {
        localStorage.removeItem(SESSION_KEY);
    }
};
