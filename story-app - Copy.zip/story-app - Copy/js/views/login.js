import { Store } from '../store.js';

export const LoginView = {
    async render() {
        return `
            <div class="header fade-in">
                <a href="#/" class="logo">Story<span>App</span></a>
                <a href="#/register" class="btn btn-secondary">Sign Up</a>
            </div>
            
            <div class="fade-in" style="max-width: 400px; margin: 4rem auto; animation-delay: 0.1s;">
                <h1 class="text-center mb-4">Welcome Back</h1>
                <form id="login-form">
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" id="username" name="username" required placeholder="Enter your username">
                    </div>
                    
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="text" id="password" name="password" required placeholder="Enter your password" style="-webkit-text-security: disc;">
                    </div>
                    
                    <div class="actions" style="justify-content: center;">
                        <button type="submit" class="btn btn-primary" style="width: 100%;">Log In</button>
                    </div>
                    <p class="text-center mt-4" style="color: var(--text-secondary);">
                        Don't have an account? <a href="#/register">Sign up</a>
                    </p>
                </form>
            </div>
        `;
    },

    async afterRender() {
        const form = document.getElementById('login-form');
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;

            if (Store.login(username, password)) {
                window.location.hash = '/';
            } else {
                alert('Invalid username or password');
            }
        });
    }
};
