import { Autosave } from '../autosave.js';
import { Export } from '../export.js';
import { Store } from '../store.js';

export const StoryFormView = {
    async render(params) {
        // Initialize autosave system
        Autosave.init((status) => {
            const indicator = document.getElementById('autosave-indicator');
            if (!indicator) return;

            if (status === 'saving') {
                indicator.textContent = 'Saving...';
                indicator.className = 'autosave-indicator saving';
            } else if (status === 'saved') {
                const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                indicator.textContent = `Saved ${time}`;
                indicator.className = 'autosave-indicator saved';
            } else if (status === 'error') {
                indicator.textContent = 'Error saving';
                indicator.className = 'autosave-indicator error';
            }
        });

        // Load story logic - check if editing existing story from Store
        let story = { title: '', content: '', targetWords: 0 };
        const isEdit = params && params.id;

        if (isEdit) {
            // Try to load from Store first (for editing published stories)
            const publishedStory = Store.getStory(params.id);
            if (publishedStory) {
                story = {
                    title: publishedStory.title,
                    content: publishedStory.content,
                    targetWords: publishedStory.targetWords || 0
                };
            } else {
                // If not in Store, try Autosave drafts
                const draftId = params.id;
                const loaded = Autosave.getDraft(draftId);
                if (loaded) {
                    story = loaded;
                    Autosave.setCurrentDraftId(draftId);
                } else {
                    // Not found anywhere
                    return `
                        <div class="header fade-in">
                            <a href="#/" class="logo">Story<span>App</span></a>
                        </div>
                        <div class="text-center fade-in" style="margin-top: 4rem;">
                            <h1>Story not found</h1>
                            <a href="#/" class="btn btn-primary mt-4">Go Home</a>
                        </div>
                    `;
                }
            }
        } else {
            // New story - try to load from autosave draft if exists
            const draftId = Autosave.getCurrentDraftId();
            if (draftId) {
                const loaded = Autosave.getDraft(draftId);
                if (loaded) {
                    story = loaded;
                }
            }
        }

        // Render Editor UI
        return `
            <!-- Focus Mode Toggle & Progress Bar Container -->
            <div id="editor-controls" class="fade-in">
                <div class="toolbar">
                    <div class="toolbar-left">
                        <button id="btn-new-draft" class="btn btn-secondary btn-sm">New Draft</button>
                        <button id="btn-drafts-list" class="btn btn-secondary btn-sm">Drafts</button>
                    </div>
                    
                    <div class="toolbar-center">
                        <input type="text" id="title" name="title" value="${story.title}" placeholder="Untitled Story" autocomplete="off">
                    </div>

                    <div class="toolbar-right">
                        <span id="autosave-indicator" class="autosave-indicator"></span>
                        <button id="btn-save-now" class="btn btn-primary btn-sm">Save Now</button>
                        
                        <div class="dropdown">
                            <button id="btn-export" class="btn btn-secondary btn-sm">Export ▼</button>
                            <div id="export-menu" class="dropdown-content">
                                <a href="#" id="export-txt">Text (.txt)</a>
                                <a href="#" id="export-pdf">PDF (Print)</a>
                            </div>
                        </div>

                        <button id="btn-focus-mode" class="btn btn-secondary btn-sm" title="Toggle Focus Mode (Ctrl+Shift+F)">
                            Focus
                        </button>
                    </div>
                </div>

                <div class="progress-bar-container">
                    <div id="progress-fill" class="progress-fill" style="width: 0%"></div>
                </div>
                
                <div class="stats-bar">
                    <span id="word-count">0 words</span>
                    <span id="reading-time">~1 min read</span>
                    <div class="target-wrapper">
                        <label for="target-words">Target words</label>
                        <input type="number" id="target-words" value="${story.targetWords || ''}" placeholder="0" min="0">
                    </div>
                </div>
            </div>
            
            <div class="editor-container fade-in">
                <textarea id="content" name="content" placeholder="Start writing your masterpiece...">${story.content}</textarea>
            </div>

            <!-- Drafts Modal -->
            <div id="drafts-modal" class="modal hidden">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2>Your Drafts</h2>
                        <button id="close-drafts" class="close-btn">&times;</button>
                    </div>
                    <div id="drafts-list" class="drafts-list">
                        <!-- Drafts injected here -->
                    </div>
                </div>
            </div>

            <!-- Focus Mode Exit Hint -->
            <div id="focus-hint" class="focus-hint hidden">
                Press ESC to exit Focus Mode
            </div>
        `;
    },

    async afterRender(params) {
        const titleInput = document.getElementById('title');
        const contentInput = document.getElementById('content');
        const targetInput = document.getElementById('target-words');
        const saveBtn = document.getElementById('btn-save-now');
        const newDraftBtn = document.getElementById('btn-new-draft');
        const draftsListBtn = document.getElementById('btn-drafts-list');
        const draftsModal = document.getElementById('drafts-modal');
        const closeDraftsBtn = document.getElementById('close-drafts');
        const focusBtn = document.getElementById('btn-focus-mode');
        const exportBtn = document.getElementById('btn-export');
        const exportMenu = document.getElementById('export-menu');
        const exportTxt = document.getElementById('export-txt');
        const exportPdf = document.getElementById('export-pdf');

        // Current Draft State
        let currentId = Autosave.getCurrentDraftId();

        // If no current draft, create one immediately
        if (!currentId) {
            const newDraft = Autosave.createDraft({ title: '', content: '' });
            currentId = newDraft.id;
        }

        // --- Helper: Update Progress ---
        const updateProgress = () => {
            const text = contentInput.value || '';
            const words = text.trim().split(/\s+/).filter(Boolean).length;
            const target = parseInt(targetInput.value) || 0;

            // Update stats text
            document.getElementById('word-count').textContent = `${words} words`;
            document.getElementById('reading-time').textContent = `~${Math.max(1, Math.ceil(words / 200))} min read`;

            // Update progress bar
            const fill = document.getElementById('progress-fill');
            if (target > 0) {
                const percent = Math.min(100, Math.round((words / target) * 100));
                fill.style.width = `${percent}%`;

                // Color states
                fill.className = 'progress-fill'; // reset
                if (percent >= 90) fill.classList.add('progress-green');
                else if (percent >= 50) fill.classList.add('progress-amber');
                else fill.classList.add('progress-red');
            } else {
                fill.style.width = '0%';
            }
        };

        // --- Helper: Save Current State ---
        const saveCurrentState = () => {
            Autosave.triggerSave(currentId, {
                title: titleInput.value,
                content: contentInput.value,
                targetWords: parseInt(targetInput.value) || 0
            });
        };

        // --- Event Listeners ---

        // Input handling (Autosave & Progress)
        [titleInput, contentInput, targetInput].forEach(el => {
            el.addEventListener('input', () => {
                updateProgress();
                saveCurrentState();
            });
        });

        // Initial progress update
        updateProgress();

        // Save Now button - Save to storyApp.stories and navigate to home
        saveBtn.addEventListener('click', () => {
            const title = titleInput.value.trim();
            const content = contentInput.value.trim();

            // Validation
            if (!content) {
                alert('Please write some content before saving.');
                contentInput.focus();
                return;
            }

            const targetWords = parseInt(targetInput.value) || 0;

            const storyData = {
                title: title || 'Untitled',
                content,
                targetWords,
                genre: '',
                shortDescription: content.substring(0, 150),
                coverImageUrl: ''
            };

            try {
                // Check if we're editing an existing story
                if (params && params.id) {
                    const existingStory = Store.getStory(params.id);
                    if (existingStory) {
                        // Update existing story
                        Store.updateStory(params.id, storyData);
                    } else {
                        // Story not found in Store, create new
                        Store.addStory(storyData);
                    }
                } else {
                    // Create new story
                    Store.addStory(storyData);
                }

                // Navigate to home - hash change will trigger re-render in SPA
                window.location.hash = '/';
            } catch (e) {
                console.error('Error saving story:', e);
                alert('Error saving story: ' + e.message);
            }
        });


        // New Draft
        newDraftBtn.addEventListener('click', () => {
            if (confirm('Create a new draft? Unsaved changes in current draft will be preserved.')) {
                const draft = Autosave.createDraft({});
                window.location.hash = `/edit/${draft.id}`;
                window.location.reload(); // Simple reload to reset state
            }
        });

        // Drafts List
        const renderDraftsList = () => {
            const list = document.getElementById('drafts-list');
            const drafts = Autosave.loadAllDrafts();

            list.innerHTML = drafts.map(d => `
                <div class="draft-item ${d.id === currentId ? 'active' : ''}">
                    <div class="draft-info">
                        <h3>${d.title || 'Untitled'}</h3>
                        <span class="meta">Last edited: ${new Date(d.updatedAt).toLocaleString()}</span>
                    </div>
                    <div class="draft-actions">
                        <button class="btn btn-sm btn-secondary open-draft" data-id="${d.id}">Open</button>
                        <button class="btn btn-sm btn-danger delete-draft" data-id="${d.id}">Delete</button>
                    </div>
                </div>
            `).join('');

            // Bind events
            list.querySelectorAll('.open-draft').forEach(b => {
                b.addEventListener('click', (e) => {
                    const id = e.target.dataset.id;
                    Autosave.setCurrentDraftId(id);
                    window.location.hash = `/edit/${id}`;
                    window.location.reload();
                });
            });

            list.querySelectorAll('.delete-draft').forEach(b => {
                b.addEventListener('click', (e) => {
                    if (confirm('Delete this draft?')) {
                        Autosave.deleteDraft(e.target.dataset.id);
                        renderDraftsList();
                    }
                });
            });
        };

        draftsListBtn.addEventListener('click', () => {
            renderDraftsList();
            draftsModal.classList.remove('hidden');
        });

        closeDraftsBtn.addEventListener('click', () => {
            draftsModal.classList.add('hidden');
        });

        // Export
        exportBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            exportMenu.classList.toggle('show');
        });

        window.addEventListener('click', () => {
            exportMenu.classList.remove('show');
        });

        exportTxt.addEventListener('click', (e) => {
            e.preventDefault();
            Export.toTXT(Autosave.getDraft(currentId));
        });

        exportPdf.addEventListener('click', (e) => {
            e.preventDefault();
            Export.toPDF(Autosave.getDraft(currentId));
        });

        // Focus Mode
        const toggleFocusMode = () => {
            document.body.classList.toggle('focus-mode');
            const isFocused = document.body.classList.contains('focus-mode');

            if (isFocused && Autosave.shouldShowFocusHint()) {
                const hint = document.getElementById('focus-hint');
                hint.classList.remove('hidden');
                setTimeout(() => {
                    hint.classList.add('hidden');
                    Autosave.dismissFocusHint();
                }, 3000);
            }
        };

        focusBtn.addEventListener('click', toggleFocusMode);

        // Keyboard Shortcuts
        document.addEventListener('keydown', (e) => {
            // Ctrl+Shift+F for Focus Mode
            if (e.ctrlKey && e.shiftKey && (e.key === 'F' || e.key === 'f')) {
                e.preventDefault();
                toggleFocusMode();
            }
            // ESC to exit Focus Mode
            if (e.key === 'Escape' && document.body.classList.contains('focus-mode')) {
                toggleFocusMode();
            }
        });

        // Sync across tabs
        window.addEventListener('storage', (e) => {
            if (e.key === 'storyapp:drafts' || e.key === 'storyapp:currentDraftId') {
                // Optional: Show toast or auto-reload
                // For now, just log it. A full reload might be disruptive if typing.
                console.log('Storage updated in another tab');
            }
        });
    }
};
