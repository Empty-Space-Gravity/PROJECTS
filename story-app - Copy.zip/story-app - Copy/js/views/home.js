import { Store } from '../store.js';

export const HomeView = {
    async render() {
        const stories = Store.getStories();
        const user = Store.getCurrentUser();

        return `
            <div class="header fade-in">
                <a href="#/" class="logo">Story<span>App</span></a>
                <div class="nav-actions">
                    ${user ? `
                        <span style="margin-right: 1rem; color: var(--text-secondary); font-family: var(--font-display); font-size: 0.9rem;">COMMANDER ${user.username.toUpperCase()}</span>
                        <a href="#/create" class="btn btn-primary">
                            <span style="margin-right: 8px;">+</span> Write Story
                        </a>
                        <button id="logout-btn" class="btn btn-secondary" style="margin-left: 0.5rem;">Logout</button>
                    ` : `
                        <a href="#/login" class="btn btn-secondary">Log In</a>
                        <a href="#/register" class="btn btn-primary" style="margin-left: 0.5rem;">Sign Up</a>
                    `}
                </div>
            </div>
            
            <div class="hero text-center mb-4 fade-in" style="animation-delay: 0.1s;">
                <h1 style="margin-bottom: 1rem;">Share Your <span style="color: var(--accent-primary); text-shadow: var(--neon-glow);">Darkest</span> Tales</h1>
                <p style="color: var(--text-secondary); max-width: 600px; margin: 0 auto; font-size: 1.2rem;">
                    A premium space for your thoughts, adventures, and imagination.
                </p>
            </div>

            <div class="story-grid">
                ${stories.length === 0 ?
                `<div class="text-center fade-in" style="grid-column: 1/-1; padding: 4rem 0; animation-delay: 0.2s;">
                        <div style="font-size: 4rem; margin-bottom: 1rem; opacity: 0.2;">📝</div>
                        <h3 style="color: var(--text-secondary);">No stories yet</h3>
                        <p style="color: var(--text-secondary);">Be the first to write one!</p>
                        ${user ? `<a href="#/create" class="btn btn-primary mt-4">Start Writing</a>` : ''}
                    </div>`
                : stories.map((story, index) => {
                    const wordCount = story.content.trim().split(/\s+/).filter(Boolean).length;
                    return `
                        <a href="#/story/${story.id}" class="story-card fade-in" style="animation-delay: ${0.2 + (index * 0.1)}s;">
                            <div class="story-card-content">
                                <h3>${story.title}</h3>
                                <div class="excerpt">${story.content.substring(0, 150)}...</div>
                                <div class="meta">
                                    <span>${story.authorName || 'Anonymous'}</span>
                                    <span style="color: var(--accent-primary);">•</span>
                                    <span>${wordCount} words</span>
                                    <span style="color: var(--accent-primary);">•</span>
                                    ${new Date(story.createdAt).toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' })}
                                </div>
                            </div>
                        </a>
                    `;
                }).join('')}
            </div>
        `;
    },

    async afterRender() {
        const logoutBtn = document.getElementById('logout-btn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', () => {
                Store.logout();
                window.location.reload();
            });
        }

        // 3D Tilt Effect
        const cards = document.querySelectorAll('.story-card');
        cards.forEach(card => {
            card.addEventListener('mousemove', (e) => {
                const rect = card.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;

                const centerX = rect.width / 2;
                const centerY = rect.height / 2;

                const rotateX = ((y - centerY) / centerY) * -10; // Max 10deg rotation
                const rotateY = ((x - centerX) / centerX) * 10;

                card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.02, 1.02, 1.02)`;
            });

            card.addEventListener('mouseleave', () => {
                card.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) scale3d(1, 1, 1)';
            });
        });
    }
};
