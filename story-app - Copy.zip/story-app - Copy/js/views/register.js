import { Store } from '../store.js';

export const RegisterView = {
    async render() {
        return `
            <div class="header fade-in">
                <a href="#/" class="logo">Story<span>App</span></a>
                <a href="#/login" class="btn btn-secondary">Log In</a>
            </div>
            
            <div class="fade-in" style="max-width: 400px; margin: 4rem auto; animation-delay: 0.1s;">
                <h1 class="text-center mb-4">Join the Story</h1>
                <form id="register-form">
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" id="username" name="username" required placeholder="Choose a username">
                    </div>
                    
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="text" id="password" name="password" required placeholder="Choose a password" style="-webkit-text-security: disc;">
                    </div>
                    
                    <div class="actions" style="justify-content: center;">
                        <button type="submit" class="btn btn-primary" style="width: 100%;">Sign Up</button>
                    </div>
                    <p class="text-center mt-4" style="color: var(--text-secondary);">
                        Already have an account? <a href="#/login">Log in</a>
                    </p>
                </form>
            </div>
        `;
    },

    async afterRender() {
        const form = document.getElementById('register-form');
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;

            if (Store.register(username, password)) {
                window.location.hash = '/';
            } else {
                alert('Username already exists');
            }
        });
    }
};
