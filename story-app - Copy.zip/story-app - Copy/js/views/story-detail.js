import { Store } from '../store.js';

export const StoryDetailView = {
    async render(params) {
        const story = Store.getStory(params.id);
        const currentUser = Store.getCurrentUser();

        if (!story) {
            return `
                <div class="header fade-in">
                    <a href="#/" class="logo">Story<span>App</span></a>
                </div>
                <div class="text-center fade-in" style="margin-top: 4rem;">
                    <h1 style="color: var(--text-secondary);">Story not found</h1>
                    <a href="#/" class="btn btn-primary mt-4">Go Home</a>
                </div>
            `;
        }

        const isAuthor = currentUser && currentUser.username === story.authorId;

        return `
            <div class="header fade-in">
                <a href="#/" class="logo">Story<span>App</span></a>
                <a href="#/" class="btn btn-secondary">← Back to Stories</a>
            </div>

            <div class="story-detail">
                <div class="story-header fade-in" style="animation-delay: 0.1s;">
                    <h1>${story.title}</h1>
                    <div class="story-meta">
                        By ${story.authorName || 'Anonymous'} • Published on ${new Date(story.createdAt).toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                    </div>
                </div>

                <div class="story-content fade-in" style="animation-delay: 0.2s;">
                    ${story.content.split('\n').map(para => para.trim() ? `<p>${para}</p>` : '').join('')}
                </div>

                ${isAuthor ? `
                    <div class="actions fade-in" style="animation-delay: 0.3s;">
                        <a href="#/edit/${story.id}" class="btn btn-secondary">Edit Story</a>
                        <button id="delete-btn" class="btn btn-danger">Delete Story</button>
                    </div>
                ` : ''}
            </div>
        `;
    },

    async afterRender(params) {
        const deleteBtn = document.getElementById('delete-btn');
        if (deleteBtn) {
            deleteBtn.addEventListener('click', () => {
                if (confirm('Are you sure you want to delete this story? This action cannot be undone.')) {
                    Store.deleteStory(params.id);
                    window.location.hash = '/';
                }
            });
        }
    }
};
