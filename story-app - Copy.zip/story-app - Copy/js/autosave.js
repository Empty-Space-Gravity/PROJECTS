/**
 * Autosave Module
 * Handles draft persistence using localStorage with 'storyapp:' namespace.
 */

const STORAGE_KEYS = {
    DRAFTS: 'storyapp:drafts',
    CURRENT_DRAFT_ID: 'storyapp:currentDraftId',
    AUTOSAVE_INTERVAL: 'storyapp:autosaveIntervalMs',
    DISMISSED_FOCUS_HINT: 'storyapp:dismissedFocusHint'
};

const DEFAULT_AUTOSAVE_INTERVAL = 2000;
const MAX_DRAFTS = 50;

let autosaveTimer = null;
let intervalTimer = null;
let isDirty = false;

export const Autosave = {
    // --- Core Storage API ---

    getDrafts() {
        try {
            const data = localStorage.getItem(STORAGE_KEYS.DRAFTS);
            return data ? JSON.parse(data) : {};
        } catch (e) {
            console.error('Error reading drafts:', e);
            return {};
        }
    },

    saveDrafts(drafts) {
        try {
            localStorage.setItem(STORAGE_KEYS.DRAFTS, JSON.stringify(drafts));
        } catch (e) {
            console.error('Error saving drafts (Storage likely full):', e);
            throw new Error('Local storage full');
        }
    },

    getCurrentDraftId() {
        return localStorage.getItem(STORAGE_KEYS.CURRENT_DRAFT_ID);
    },

    setCurrentDraftId(id) {
        localStorage.setItem(STORAGE_KEYS.CURRENT_DRAFT_ID, id);
    },

    // --- Draft Management ---

    createDraft({ title = 'Untitled Story', content = '', targetWords = 0 }) {
        const id = `draft_${Date.now()}`;
        const draft = {
            id,
            title,
            content,
            createdAt: Date.now(),
            updatedAt: Date.now(),
            targetWords: parseInt(targetWords) || 0
        };

        const drafts = this.getDrafts();

        // Enforce limit
        const draftIds = Object.keys(drafts);
        if (draftIds.length >= MAX_DRAFTS) {
            // Find oldest and remove
            let oldestId = draftIds[0];
            let oldestTime = drafts[oldestId].updatedAt;

            for (const dId of draftIds) {
                if (drafts[dId].updatedAt < oldestTime) {
                    oldestTime = drafts[dId].updatedAt;
                    oldestId = dId;
                }
            }
            delete drafts[oldestId];
        }

        drafts[id] = draft;
        this.saveDrafts(drafts);
        this.setCurrentDraftId(id);
        return draft;
    },

    getDraft(id) {
        const drafts = this.getDrafts();
        return drafts[id] || null;
    },

    updateDraft(id, updates) {
        const drafts = this.getDrafts();
        if (!drafts[id]) return null;

        drafts[id] = {
            ...drafts[id],
            ...updates,
            updatedAt: Date.now()
        };

        this.saveDrafts(drafts);
        return drafts[id];
    },

    deleteDraft(id) {
        const drafts = this.getDrafts();
        if (drafts[id]) {
            delete drafts[id];
            this.saveDrafts(drafts);

            if (this.getCurrentDraftId() === id) {
                localStorage.removeItem(STORAGE_KEYS.CURRENT_DRAFT_ID);
            }
        }
    },

    loadAllDrafts() {
        const drafts = this.getDrafts();
        return Object.values(drafts).sort((a, b) => b.updatedAt - a.updatedAt);
    },

    // --- Autosave Logic ---

    init(onSaveStatusChange) {
        // Clear any existing timers
        this.stop();

        // Set up interval fallback
        const intervalMs = parseInt(localStorage.getItem(STORAGE_KEYS.AUTOSAVE_INTERVAL)) || DEFAULT_AUTOSAVE_INTERVAL;

        // We only start the interval timer when there are changes, or we can run it continuously to check for dirty state
        // For simplicity and robustness, we'll use the debounce method primarily, and a backup interval check

        this.onSaveStatusChange = onSaveStatusChange;
    },

    triggerSave(id, data) {
        if (!id) return;

        isDirty = true;
        if (this.onSaveStatusChange) this.onSaveStatusChange('saving');

        // Clear existing debounce timer
        if (autosaveTimer) clearTimeout(autosaveTimer);

        // Debounce 1.5s
        autosaveTimer = setTimeout(() => {
            this.performSave(id, data);
        }, 1500);
    },

    performSave(id, data) {
        if (!isDirty) return;

        try {
            this.updateDraft(id, data);
            isDirty = false;
            if (this.onSaveStatusChange) this.onSaveStatusChange('saved');
        } catch (e) {
            if (this.onSaveStatusChange) this.onSaveStatusChange('error');
        }
    },

    stop() {
        if (autosaveTimer) clearTimeout(autosaveTimer);
        if (intervalTimer) clearInterval(intervalTimer);
    },

    // --- Focus Mode Hint ---

    shouldShowFocusHint() {
        return !localStorage.getItem(STORAGE_KEYS.DISMISSED_FOCUS_HINT);
    },

    dismissFocusHint() {
        localStorage.setItem(STORAGE_KEYS.DISMISSED_FOCUS_HINT, 'true');
    }
};
