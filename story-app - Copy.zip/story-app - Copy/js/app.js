import { HomeView } from './views/home.js';
import { StoryFormView } from './views/story-form.js';
import { StoryDetailView } from './views/story-detail.js';
import { LoginView } from './views/login.js';
import { RegisterView } from './views/register.js';
import { Store } from './store.js';

const routes = [
    { path: '/', view: HomeView },
    { path: '/create', view: StoryFormView, protected: true },
    { path: '/story/:id', view: StoryDetailView },
    { path: '/edit/:id', view: StoryFormView, protected: true },
    { path: '/login', view: LoginView },
    { path: '/register', view: RegisterView }
];

const app = document.getElementById('app');

async function router() {
    const hash = window.location.hash.slice(1) || '/';
    const urlParts = hash.split('/');

    let match = null;
    let params = {};

    if (hash === '/' || hash === '') {
        match = routes.find(r => r.path === '/');
    } else if (urlParts[1] === 'create') {
        match = routes.find(r => r.path === '/create');
    } else if (urlParts[1] === 'story' && urlParts[2]) {
        match = routes.find(r => r.path === '/story/:id');
        params.id = urlParts[2];
    } else if (urlParts[1] === 'edit' && urlParts[2]) {
        match = routes.find(r => r.path === '/edit/:id');
        params.id = urlParts[2];
    } else if (urlParts[1] === 'login') {
        match = routes.find(r => r.path === '/login');
    } else if (urlParts[1] === 'register') {
        match = routes.find(r => r.path === '/register');
    }

    if (match) {
        if (match.protected && !Store.getCurrentUser()) {
            window.location.hash = '/login';
            return;
        }

        app.innerHTML = await match.view.render(params);
        if (match.view.afterRender) {
            await match.view.afterRender(params);
        }
    } else {
        app.innerHTML = '<h1 class="text-center" style="margin-top: 4rem;">404 - Page Not Found</h1>';
    }
}

window.addEventListener('hashchange', router);
window.addEventListener('load', router);

// Global navigation helper
window.navigateTo = (url) => {
    window.location.hash = url;
};
