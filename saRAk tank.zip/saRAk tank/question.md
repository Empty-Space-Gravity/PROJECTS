Rubrics

✅ Shows the correct initial data - 3 marks 
✅ Able to add new pitch - 2 marks
✅ Able to delete a pitch - 2 marks
✅ Able to edit all fields of the pitch - 2 marks
✅ Able to edit the price - 1 mark
✅ Sorts as expected - 1 mark
✅ Filters as expected - 1 mark
✅ Able to search by title - 1 mark
✅ Able to search by the founder - 1 mark

